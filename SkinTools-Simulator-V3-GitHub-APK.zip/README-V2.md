# Skin Simulator V2 — GitHub + APK + Supabase

## Có gì mới
- Catalog skin/súng/trợ thủ/hiệu ứng có thể tải từ Supabase.
- Key được kiểm tra bằng RPC `redeem_key`, không đọc trực tiếp bảng key.
- Có `admin.html` cho đăng nhập admin và thêm catalog.
- Có `supabase-schema.sql`.
- GitHub Actions build APK.

## Cài đặt trên iPhone
1. Tạo repo GitHub.
2. Upload toàn bộ nội dung thư mục này.
3. Trong `app/src/main/assets/supabase-config.js`, thay:
   - `url`
   - `anonKey`
   - `getKeyUrl`
4. Supabase SQL Editor: chạy `supabase-schema.sql`.
5. Tạo user admin trong Authentication, sau đó thêm UUID user vào bảng `admins`.
6. Vào GitHub > Actions > Build APK > Run workflow.
7. Tải artifact `skin-simulator-debug-apk`.

## Link lấy key
`getKeyUrl` là nơi bạn đặt link rút gọn. V2 chỉ mở link đó; việc phát key thực tế nên do hệ thống/server của bạn kiểm soát.

## Bảo mật
- Không đặt `service_role` key trong APK.
- RLS phải bật.
- Bảng `sim_keys` không được cho client đọc trực tiếp.
- Với admin production, nên dùng Edge Function/RPC bảo vệ để tạo/thu hồi key.
