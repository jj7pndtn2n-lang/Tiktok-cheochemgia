# Skin Tools Simulator V3

Bố cục được làm theo phong cách video đã gửi: chọn Free Fire/Free Fire Max, tab Skin Súng/Skin Nhân Vật/Skin Khác, card ảnh + CÀI ĐẶT + CHI TIẾT.

Luồng:
MỞ APP → CHỌN NỘI DUNG → CÀI ĐẶT → NHẬP KEY → LINK LẤY KEY → SUPABASE XÁC THỰC → HỢP LỆ → MỞ TRANG/MỞ APP.

Admin:
- đăng nhập Supabase Auth
- đăng ảnh PNG/JPG/WebP
- thêm skin/súng/nội dung
- chọn game
- đặt tên/badge/link chi tiết/thứ tự
- ẩn/hiện nội dung
- tạo key theo số lượt

Thiết lập:
1. Chạy supabase-schema.sql trong Supabase SQL Editor.
2. Tạo user admin trong Authentication.
3. Chèn UUID user vào public.admins.
4. Sửa app/src/main/assets/supabase-config.js với URL, anon key, link lấy key và destinationUrl.
5. Upload source lên GitHub.
6. GitHub Actions → Build APK → Run workflow.

destinationUrl có thể là website hoặc deep link của ứng dụng mà bạn sở hữu/được phép mở.

Không chỉnh sửa client game, không inject và không bypass anti-cheat.
