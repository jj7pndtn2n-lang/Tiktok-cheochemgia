# FreeFireStyleSimulator

Bản Android demo đóng gói giao diện simulator từ web demo vào APK.

## Build bằng iPhone + GitHub

1. Tạo repository GitHub mới.
2. Upload toàn bộ file/thư mục trong project này.
3. Đảm bảo có `.github/workflows/build-apk.yml`.
4. Vào tab **Actions**.
5. Chọn **Build APK**.
6. Bấm **Run workflow**.
7. Khi chạy xong, mở workflow run → phần **Artifacts** → tải `skin-simulator-debug-apk`.

Lưu ý:
- Đây là simulator độc lập.
- Không sửa APK/file Free Fire.
- Không bypass anti-cheat.
- Các hình/emoji trong demo là asset mô phỏng; thay bằng asset bạn có quyền sử dụng khi phát triển tiếp.
